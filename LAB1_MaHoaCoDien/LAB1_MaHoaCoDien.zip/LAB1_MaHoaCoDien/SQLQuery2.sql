﻿-- 1. Tạo Database và Bảng lưu lịch sử
IF DB_ID(N'LAB1_MaHoaCoDien') IS NULL
    CREATE DATABASE [LAB1_MaHoaCoDien];
GO
USE [LAB1_MaHoaCoDien];
GO
IF OBJECT_ID(N'dbo.history', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.history (
        id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        created_at DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
        algorithm NVARCHAR(50) NOT NULL,
        operation VARCHAR(10) NOT NULL,
        input_text NVARCHAR(MAX) NOT NULL,
        result_text NVARCHAR(MAX) NOT NULL,
        CONSTRAINT CK_lab1_operation CHECK (operation IN ('ENCRYPT','DECRYPT'))
    );
END;
GO

-- 2. Tạo tài khoản và phân quyền (Đã ẩn mật khẩu thực tế)
USE [master];
GO
IF NOT EXISTS (SELECT 1 FROM sys.sql_logins WHERE name = N'lab1_user')
BEGIN
    CREATE LOGIN [lab1_user]
    WITH PASSWORD = '<MAT_KHAU_CUA_BAN>',
         CHECK_POLICY = ON,
         CHECK_EXPIRATION = OFF;
END;
GO
USE [LAB1_MaHoaCoDien];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'lab1_user')
    CREATE USER [lab1_user] FOR LOGIN [lab1_user];
GO
GRANT SELECT, INSERT, DELETE ON OBJECT::dbo.history TO [lab1_user];
GO

-- 3. Truy vấn kiểm tra dữ liệu lịch sử
SELECT TOP 50 id, created_at, algorithm, operation, input_text, result_text
FROM dbo.history
ORDER BY id DESC;
GO